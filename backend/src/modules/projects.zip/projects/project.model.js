import mongoose from "mongoose";


// =====================================================
// PROJECT SCHEMA
// =====================================================

const projectSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },

    role: {
      type: String,
      required: true,
      trim: true,
    },

    difficulty: {
      type: String,
      enum: ["junior", "mid", "senior"],
      required: true,
    },

    description: {
      type: String,
      default: "",
      trim: true,
    },

    technologies: {
      type: [String],
      default: [],
    },

    briefUrl: {
      type: String,
      default: "",
      trim: true,
    },

    status: {
      type: String,
      enum: ["active", "archived"],
      default: "active",
    },
  },
  {
    timestamps: true,
  }
);


// =====================================================
// MODEL
// =====================================================

const Project =
  mongoose.models.Project ||
  mongoose.model("Project", projectSchema);


// =====================================================
// EXPORT
// =====================================================

export default Project;