import express from "express";

import {
  getProjects,
  getProjectById,
  createProject,
  updateProject,
  archiveProject,
  deleteProject,
} from "./project.controller.js";


const router = express.Router();


// =====================================================
// GET ALL PROJECTS
// GET /api/projects
// =====================================================

router.get(
  "/",
  getProjects
);


// =====================================================
// GET PROJECT BY ID
// GET /api/projects/:id
// =====================================================

router.get(
  "/:id",
  getProjectById
);


// =====================================================
// CREATE PROJECT
// POST /api/projects
// =====================================================

router.post(
  "/",
  createProject
);


// =====================================================
// UPDATE PROJECT
// PATCH /api/projects/:id
// =====================================================

router.patch(
  "/:id",
  updateProject
);


// =====================================================
// UPDATE PROJECT
// PUT /api/projects/:id
// =====================================================

router.put(
  "/:id",
  updateProject
);


// =====================================================
// ARCHIVE PROJECT
// PATCH /api/projects/:id/archive
// =====================================================

router.patch(
  "/:id/archive",
  archiveProject
);


// =====================================================
// DELETE PROJECT
// DELETE /api/projects/:id
// =====================================================

router.delete(
  "/:id",
  deleteProject
);


// =====================================================
// EXPORT
// =====================================================

export default router;