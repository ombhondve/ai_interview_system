import Project from "./project.model.js";


// =====================================================
// GET ALL PROJECTS
// GET /api/projects
// =====================================================

export const getProjects = async (req, res) => {
  try {

    const projects = await Project
      .find()
      .sort({ createdAt: -1 })
      .lean();

    return res.status(200).json({
      success: true,
      projects,
    });

  } catch (error) {

    console.error(
      "Get projects error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to fetch projects.",
    });

  }
};


// =====================================================
// GET PROJECT BY ID
// GET /api/projects/:id
// =====================================================

export const getProjectById = async (req, res) => {
  try {

    const { id } = req.params;

    const project = await Project
      .findById(id)
      .lean();

    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    return res.status(200).json({
      success: true,
      project,
    });

  } catch (error) {

    console.error(
      "Get project by ID error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to fetch project.",
    });

  }
};


// =====================================================
// CREATE PROJECT
// POST /api/projects
// =====================================================

export const createProject = async (req, res) => {
  try {

    const {
      title,
      role,
      difficulty,
      description,
      technologies,
      briefUrl,
      status,
    } = req.body;


    // -------------------------------------------------
    // VALIDATION
    // -------------------------------------------------

    if (!title || !title.trim()) {
      return res.status(400).json({
        success: false,
        message: "Project title is required.",
      });
    }

    if (!role || !role.trim()) {
      return res.status(400).json({
        success: false,
        message: "Project role is required.",
      });
    }

    if (
      !difficulty ||
      !["junior", "mid", "senior"].includes(
        difficulty
      )
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Difficulty must be junior, mid, or senior.",
      });
    }


    // -------------------------------------------------
    // CREATE PROJECT
    // -------------------------------------------------

    const project = await Project.create({

      title: title.trim(),

      role: role.trim(),

      difficulty,

      description:
        typeof description === "string"
          ? description.trim()
          : "",

      technologies:
        Array.isArray(technologies)
          ? technologies
              .map((item) =>
                String(item).trim()
              )
              .filter(Boolean)
          : [],

      briefUrl:
        typeof briefUrl === "string"
          ? briefUrl.trim()
          : "",

      status:
        status === "archived"
          ? "archived"
          : "active",

    });


    return res.status(201).json({
      success: true,
      message: "Project created successfully.",
      project,
    });

  } catch (error) {

    console.error(
      "Create project error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to create project.",
    });

  }
};


// =====================================================
// UPDATE PROJECT
// PATCH /api/projects/:id
// PUT /api/projects/:id
// =====================================================

export const updateProject = async (req, res) => {
  try {

    const { id } = req.params;

    const {
      title,
      role,
      difficulty,
      description,
      technologies,
      briefUrl,
      status,
    } = req.body;


    // -------------------------------------------------
    // BUILD UPDATE OBJECT
    // -------------------------------------------------

    const updateData = {};


    if (title !== undefined) {
      if (
        typeof title !== "string" ||
        !title.trim()
      ) {
        return res.status(400).json({
          success: false,
          message: "Project title cannot be empty.",
        });
      }

      updateData.title = title.trim();
    }


    if (role !== undefined) {
      if (
        typeof role !== "string" ||
        !role.trim()
      ) {
        return res.status(400).json({
          success: false,
          message: "Project role cannot be empty.",
        });
      }

      updateData.role = role.trim();
    }


    if (difficulty !== undefined) {

      if (
        !["junior", "mid", "senior"].includes(
          difficulty
        )
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Difficulty must be junior, mid, or senior.",
        });
      }

      updateData.difficulty =
        difficulty;
    }


    if (description !== undefined) {

      updateData.description =
        typeof description === "string"
          ? description.trim()
          : "";
    }


    if (technologies !== undefined) {

      if (!Array.isArray(technologies)) {
        return res.status(400).json({
          success: false,
          message:
            "Technologies must be an array.",
        });
      }

      updateData.technologies =
        technologies
          .map((item) =>
            String(item).trim()
          )
          .filter(Boolean);
    }


    if (briefUrl !== undefined) {

      updateData.briefUrl =
        typeof briefUrl === "string"
          ? briefUrl.trim()
          : "";
    }


    if (status !== undefined) {

      if (
        !["active", "archived"].includes(
          status
        )
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Status must be active or archived.",
        });
      }

      updateData.status = status;
    }


    // -------------------------------------------------
    // UPDATE
    // -------------------------------------------------

    const project =
      await Project.findByIdAndUpdate(
        id,
        updateData,
        {
          new: true,
          runValidators: true,
        }
      );


    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }


    return res.status(200).json({
      success: true,
      message: "Project updated successfully.",
      project,
    });

  } catch (error) {

    console.error(
      "Update project error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to update project.",
    });

  }
};


// =====================================================
// ARCHIVE PROJECT
// PATCH /api/projects/:id/archive
// =====================================================

export const archiveProject = async (req, res) => {
  try {

    const { id } = req.params;

    const project =
      await Project.findByIdAndUpdate(
        id,
        {
          status: "archived",
        },
        {
          new: true,
          runValidators: true,
        }
      );


    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }


    return res.status(200).json({
      success: true,
      message: "Project archived successfully.",
      project,
    });

  } catch (error) {

    console.error(
      "Archive project error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to archive project.",
    });

  }
};


// =====================================================
// DELETE PROJECT
// DELETE /api/projects/:id
// =====================================================

export const deleteProject = async (req, res) => {
  try {

    const { id } = req.params;

    const project =
      await Project.findByIdAndDelete(id);


    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }


    return res.status(200).json({
      success: true,
      message: "Project deleted successfully.",
      project,
    });

  } catch (error) {

    console.error(
      "Delete project error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to delete project.",
    });

  }
};