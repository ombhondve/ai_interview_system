const projectRoutes = require("./project.routes");
const projectController = require("./project.controller");
const projectService = require("./project.service");
const Project = require("./project.model");

module.exports = {
    projectRoutes,
    projectController,
    projectService,
    Project,
};