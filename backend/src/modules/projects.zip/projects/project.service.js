const DemoProject = require("./project.model");


// =====================================================
// GET ALL PROJECTS
// =====================================================

async function getProjects(filters = {}) {
    try {
        const {
            status,
            role,
            difficulty,
            search,
        } = filters;

        const query = {};

        // -------------------------------------------------
        // STATUS
        // -------------------------------------------------

        if (status) {
            query.status = status;
        }

        // -------------------------------------------------
        // ROLE
        // -------------------------------------------------

        if (role) {
            query.role = role;
        }

        // -------------------------------------------------
        // DIFFICULTY
        // -------------------------------------------------

        if (difficulty) {
            query.difficulty = difficulty;
        }

        // -------------------------------------------------
        // SEARCH
        // -------------------------------------------------

        if (search && search.trim()) {
            const searchRegex =
                new RegExp(
                    search.trim(),
                    "i"
                );

            query.$or = [
                {
                    title: searchRegex,
                },
                {
                    role: searchRegex,
                },
            ];
        }

        // -------------------------------------------------
        // DATABASE QUERY
        // -------------------------------------------------

        const projects =
            await DemoProject
                .find(query)
                .sort({
                    createdAt: -1,
                })
                .lean();

        return projects;

    } catch (error) {
        console.error(
            "Error getting projects:",
            error
        );

        throw error;
    }
}


// =====================================================
// GET PROJECT BY ID
// =====================================================

async function getProjectById(id) {
    try {
        const project =
            await DemoProject
                .findById(id)
                .lean();

        return project || null;

    } catch (error) {
        console.error(
            "Error getting project by ID:",
            error
        );

        throw error;
    }
}


// =====================================================
// CREATE PROJECT
// =====================================================

async function createProject(data) {
    try {
        const {
            title,
            role,
            difficulty,
            briefUrl,
        } = data;

        const project =
            await DemoProject.create({
                title,
                role,
                difficulty,
                briefUrl,
            });

        return project;

    } catch (error) {
        console.error(
            "Error creating project:",
            error
        );

        throw error;
    }
}


// =====================================================
// UPDATE PROJECT
// =====================================================

async function updateProject(
    id,
    updateData
) {
    try {
        const project =
            await DemoProject.findByIdAndUpdate(
                id,
                {
                    $set: updateData,
                },
                {
                    new: true,
                    runValidators: true,
                }
            );

        return project || null;

    } catch (error) {
        console.error(
            "Error updating project:",
            error
        );

        throw error;
    }
}


// =====================================================
// ARCHIVE PROJECT
// =====================================================

async function archiveProject(id) {
    try {
        /*
         * Your current project.model.js does not define
         * a "status" field.
         *
         * Therefore we cannot safely archive a project
         * using the current schema.
         *
         * For now, we return the project so the controller
         * can confirm that it exists.
         */

        const project =
            await DemoProject.findById(id);

        if (!project) {
            return null;
        }

        /*
         * Once "status" is added to project.model.js,
         * this should become:
         *
         * project.status = "archived";
         * await project.save();
         */

        return project;

    } catch (error) {
        console.error(
            "Error archiving project:",
            error
        );

        throw error;
    }
}


// =====================================================
// EXPORTS
// =====================================================

module.exports = {
    getProjects,
    getProjectById,
    createProject,
    updateProject,
    archiveProject,
};