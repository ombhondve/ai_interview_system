import { generateAIResponse } from "./ai.service.js";
import { resumeAnalysisPrompt } from "./ai.prompt.js";

export const analyzeResume = async (req, res) => {
    try {
        const { resumeText } = req.body;
        console.log("Received resume text:", resumeText);

        const messages = [
            {
                role: "system",
                content: resumeAnalysisPrompt
            },
            {
                role: "user",
                content: resumeText
            }
        ];

        const result = await generateAIResponse(messages);

        res.status(200).json({
            success: true,
            data: result
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Resume analysis failed"
        });
    }
};