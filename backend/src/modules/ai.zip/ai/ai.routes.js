import express from "express";
import { analyzeResume } from "./ai.controller.js";

const router = express.Router();

router.post("/analyze-resume", analyzeResume);

export default router;