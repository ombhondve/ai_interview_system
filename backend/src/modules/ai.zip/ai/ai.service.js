import Groq from "groq-sdk";

const groq = new Groq({
    apiKey: process.env.GROQ_API_KEY
});

export const generateAIResponse = async (messages) => {
    try {
        const response = await groq.chat.completions.create({
            model: "openai/gpt-oss-20b",

            messages,

            temperature: 0.1,

            response_format: {
                type: "json_object"
            }
        });

        const content =
            response?.choices?.[0]?.message?.content;

        console.log("========== GROQ RESPONSE ==========");

        if (!content) {
            console.error("Groq returned an empty response");
            console.error("Full response:", response);

            throw new Error(
                "Groq returned an empty response"
            );
        }

        console.log(content);
        console.log("===================================");

        return content;

    } catch (error) {

        console.error(
            "========== GROQ API ERROR =========="
        );

        console.error(
            "Message:",
            error?.message
        );

        console.error(
            "Full error:",
            error
        );

        console.error(
            "===================================="
        );

        throw error;
    }
};