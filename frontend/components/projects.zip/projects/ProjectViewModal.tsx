"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  AlertCircle,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Download,
  ExternalLink,
  Eye,
  FileText,
  GraduationCap,
  Pencil,
  UserPlus,
  X,
} from "lucide-react";

/* -------------------------------------------------------------------------- */
/* Types                                                                      */
/* -------------------------------------------------------------------------- */

export interface ViewProject {
  _id?: string;
  id?: string;

  title?: string;
  role?: string;

  difficulty?: string;
  description?: string;

  projectType?: string;
  duration?: string;
  focus?: string;

  technologies?: string[];
  techStack?: string[];

  requirements?: string[];

  status?: string;

  briefUrl?: string;
  pdfUrl?: string;
  detailedPdfUrl?: string;

  studentId?: string;
  studentName?: string;

  assignedCandidateId?: string;
  assignedStudentId?: string;

  createdAt?: string;
  updatedAt?: string;

  [key: string]: unknown;
}

interface ProjectViewModalProps {
  open: boolean;

  project: ViewProject | null;

  onClose: () => void;

  onEdit?: (project: ViewProject) => void;

  onAssign?: (project: ViewProject) => void;

  /**
   * Optional callback when the user wants to open
   * the dedicated AI PDF preview modal.
   */
  onPreviewPdf?: (project: ViewProject) => void;
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function getProjectId(project: ViewProject): string {
  return String(project._id || project.id || "");
}

function getTechnologies(project: ViewProject): string[] {
  if (Array.isArray(project.technologies)) {
    return project.technologies.filter(
      (item): item is string =>
        typeof item === "string" && item.trim().length > 0
    );
  }

  if (Array.isArray(project.techStack)) {
    return project.techStack.filter(
      (item): item is string =>
        typeof item === "string" && item.trim().length > 0
    );
  }

  return [];
}

function getRequirements(project: ViewProject): string[] {
  if (!Array.isArray(project.requirements)) {
    return [];
  }

  return project.requirements.filter(
    (item): item is string =>
      typeof item === "string" && item.trim().length > 0
  );
}

function formatValue(value?: string): string {
  if (!value) {
    return "Not specified";
  }

  return value
    .replace(/[_-]/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

function formatDate(value?: string): string {
  if (!value) {
    return "Not available";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "Not available";
  }

  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function formatDateTime(value?: string): string {
  if (!value) {
    return "Not available";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "Not available";
  }

  return date.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function resolvePdfUrl(value?: string): string {
  if (!value) {
    return "";
  }

  const url = value.trim();

  if (!url) {
    return "";
  }

  /*
   * Already an absolute URL.
   */
  if (
    url.startsWith("http://") ||
    url.startsWith("https://") ||
    url.startsWith("blob:") ||
    url.startsWith("data:")
  ) {
    return url;
  }

  /*
   * Protocol-relative URL.
   */
  if (url.startsWith("//")) {
    return `${window.location.protocol}${url}`;
  }

  /*
   * Relative backend URL.
   *
   * Example:
   * /uploads/projects/project.pdf
   *
   * NEXT_PUBLIC_API_URL:
   * http://localhost:5000
   */
  const apiBaseUrl =
    process.env.NEXT_PUBLIC_API_URL?.replace(/\/+$/, "") || "";

  if (apiBaseUrl) {
    if (url.startsWith("/")) {
      return `${apiBaseUrl}${url}`;
    }

    return `${apiBaseUrl}/${url}`;
  }

  /*
   * If no backend URL is configured,
   * use the current frontend origin.
   */
  if (url.startsWith("/")) {
    return url;
  }

  return `/${url}`;
}

function getPdfSource(project: ViewProject): string {
  return (
    project.detailedPdfUrl ||
    project.pdfUrl ||
    project.briefUrl ||
    ""
  );
}

function getStatusClasses(status?: string): string {
  const normalized = (status || "").toLowerCase();

  if (
    normalized === "completed" ||
    normalized === "active" ||
    normalized === "assigned"
  ) {
    return "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400";
  }

  if (
    normalized === "in_progress" ||
    normalized === "in-progress"
  ) {
    return "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400";
  }

  if (
    normalized === "archived" ||
    normalized === "cancelled" ||
    normalized === "canceled"
  ) {
    return "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400";
  }

  return "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400";
}

/* -------------------------------------------------------------------------- */
/* Component                                                                  */
/* -------------------------------------------------------------------------- */

export default function ProjectViewModal({
  open,
  project,
  onClose,
  onEdit,
  onAssign,
  onPreviewPdf,
}: ProjectViewModalProps) {
  const [pdfLoading, setPdfLoading] = useState(false);
  const [pdfError, setPdfError] = useState(false);

  /* ------------------------------------------------------------------------ */
  /* PDF URL                                                                  */
  /* ------------------------------------------------------------------------ */

  const pdfUrl = useMemo(() => {
    if (!project) {
      return "";
    }

    return resolvePdfUrl(getPdfSource(project));
  }, [
    project?.detailedPdfUrl,
    project?.pdfUrl,
    project?.briefUrl,
  ]);

  /* ------------------------------------------------------------------------ */
  /* Reset PDF state when project changes                                     */
  /* ------------------------------------------------------------------------ */

  useEffect(() => {
    if (!open) {
      setPdfLoading(false);
      setPdfError(false);
      return;
    }

    setPdfError(false);
    setPdfLoading(Boolean(pdfUrl));
  }, [open, pdfUrl]);

  /* ------------------------------------------------------------------------ */
  /* Escape key                                                               */
  /* ------------------------------------------------------------------------ */

  useEffect(() => {
    if (!open) {
      return;
    }

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
      }
    };

    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener(
        "keydown",
        handleKeyDown
      );
    };
  }, [open, onClose]);

  /* ------------------------------------------------------------------------ */
  /* Prevent background scrolling                                             */
  /* ------------------------------------------------------------------------ */

  useEffect(() => {
    if (!open) {
      return;
    }

    const previousOverflow = document.body.style.overflow;

    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  /* ------------------------------------------------------------------------ */
  /* Closed                                                                   */
  /* ------------------------------------------------------------------------ */

  if (!open || !project) {
    return null;
  }

  const projectId = getProjectId(project);
  const technologies = getTechnologies(project);
  const requirements = getRequirements(project);

  const isAssigned =
    Boolean(project.studentId) ||
    Boolean(project.studentName) ||
    Boolean(project.assignedCandidateId) ||
    Boolean(project.assignedStudentId);

  const handleBackdropClick = (
    event: React.MouseEvent<HTMLDivElement>
  ) => {
    if (event.target === event.currentTarget) {
      onClose();
    }
  };

  const handleOpenPdf = () => {
    if (!pdfUrl) {
      return;
    }

    window.open(
      pdfUrl,
      "_blank",
      "noopener,noreferrer"
    );
  };

  const handleDownloadPdf = () => {
    if (!pdfUrl) {
      return;
    }

    const link = document.createElement("a");

    link.href = pdfUrl;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.download =
      `${project.title || "project"}-details.pdf`;

    document.body.appendChild(link);

    link.click();

    document.body.removeChild(link);
  };

  return (
    <div
      className="fixed inset-0 z-[105] flex items-center justify-center bg-black/60 px-4 py-5 backdrop-blur-sm"
      onMouseDown={handleBackdropClick}
      role="dialog"
      aria-modal="true"
      aria-labelledby="project-view-title"
    >
      <div
        className="relative flex max-h-[94vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl dark:bg-slate-900"
        onMouseDown={(event) =>
          event.stopPropagation()
        }
      >
        {/* ================================================================== */}
        {/* Header                                                            */}
        {/* ================================================================== */}

        <div className="flex shrink-0 items-start justify-between border-b border-slate-200 px-6 py-5 dark:border-slate-700">
          <div className="min-w-0 pr-8">
            <div className="mb-2 flex flex-wrap items-center gap-2">
              <span
                className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${getStatusClasses(
                  project.status
                )}`}
              >
                {formatValue(
                  project.status || "created"
                )}
              </span>

              {isAssigned && (
                <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-100 px-2.5 py-1 text-xs font-medium text-blue-700 dark:bg-blue-900/30 dark:text-blue-400">
                  <UserPlus className="h-3.5 w-3.5" />
                  Assigned
                </span>
              )}
            </div>

            <h2
              id="project-view-title"
              className="break-words text-xl font-semibold text-slate-900 dark:text-white sm:text-2xl"
            >
              {project.title || "Untitled Project"}
            </h2>

            {project.role && (
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                {project.role}
              </p>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-500 transition hover:bg-slate-100 hover:text-slate-800 dark:hover:bg-slate-800 dark:hover:text-white"
            aria-label="Close project details"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* ================================================================== */}
        {/* Content                                                           */}
        {/* ================================================================== */}

        <div className="min-h-0 flex-1 overflow-y-auto">
          <div className="grid grid-cols-1 gap-6 p-6 lg:grid-cols-5">
            {/* ============================================================= */}
            {/* Left side                                                      */}
            {/* ============================================================= */}

            <div className="space-y-6 lg:col-span-3">
              {/* ----------------------------------------------------------- */}
              {/* Overview                                                     */}
              {/* ----------------------------------------------------------- */}

              <section>
                <SectionHeading
                  icon={<FileText className="h-4 w-4" />}
                  title="Project Overview"
                />

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <InfoCard
                    label="Project Type"
                    value={formatValue(
                      project.projectType
                    )}
                  />

                  <InfoCard
                    label="Difficulty"
                    value={formatValue(
                      project.difficulty
                    )}
                  />

                  <InfoCard
                    label="Duration"
                    value={
                      project.duration ||
                      "Not specified"
                    }
                  />

                  <InfoCard
                    label="Role"
                    value={
                      project.role ||
                      "Not specified"
                    }
                  />
                </div>
              </section>

              {/* ----------------------------------------------------------- */}
              {/* Description                                                  */}
              {/* ----------------------------------------------------------- */}

              <section>
                <SectionHeading
                  icon={
                    <FileText className="h-4 w-4" />
                  }
                  title="Description"
                />

                <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-800/40">
                  {project.description ? (
                    <p className="whitespace-pre-wrap text-sm leading-6 text-slate-600 dark:text-slate-300">
                      {project.description}
                    </p>
                  ) : (
                    <EmptyText text="No description available." />
                  )}
                </div>
              </section>

              {/* ----------------------------------------------------------- */}
              {/* Focus                                                        */}
              {/* ----------------------------------------------------------- */}

              {project.focus && (
                <section>
                  <SectionHeading
                    icon={
                      <Eye className="h-4 w-4" />
                    }
                    title="Project Focus"
                  />

                  <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
                    <p className="whitespace-pre-wrap text-sm leading-6 text-slate-600 dark:text-slate-300">
                      {project.focus}
                    </p>
                  </div>
                </section>
              )}

              {/* ----------------------------------------------------------- */}
              {/* Technologies                                                 */}
              {/* ----------------------------------------------------------- */}

              <section>
                <SectionHeading
                  icon={
                    <CheckCircle2 className="h-4 w-4" />
                  }
                  title="Technologies"
                />

                {technologies.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {technologies.map(
                      (technology, index) => (
                        <span
                          key={`${technology}-${index}`}
                          className="rounded-full bg-indigo-50 px-3 py-1.5 text-sm font-medium text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300"
                        >
                          {technology}
                        </span>
                      )
                    )}
                  </div>
                ) : (
                  <EmptyText text="No technologies specified." />
                )}
              </section>

              {/* ----------------------------------------------------------- */}
              {/* Requirements                                                 */}
              {/* ----------------------------------------------------------- */}

              <section>
                <SectionHeading
                  icon={
                    <CheckCircle2 className="h-4 w-4" />
                  }
                  title="Requirements"
                />

                {requirements.length > 0 ? (
                  <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
                    <ul className="space-y-3">
                      {requirements.map(
                        (requirement, index) => (
                          <li
                            key={`${requirement}-${index}`}
                            className="flex items-start gap-3 text-sm leading-6 text-slate-600 dark:text-slate-300"
                          >
                            <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-500" />

                            <span>
                              {requirement}
                            </span>
                          </li>
                        )
                      )}
                    </ul>
                  </div>
                ) : (
                  <EmptyText text="No requirements specified." />
                )}
              </section>
            </div>

            {/* ============================================================= */}
            {/* Right side                                                     */}
            {/* ============================================================= */}

            <div className="space-y-6 lg:col-span-2">
              {/* ----------------------------------------------------------- */}
              {/* Student                                                      */}
              {/* ----------------------------------------------------------- */}

              <section>
                <SectionHeading
                  icon={
                    <GraduationCap className="h-4 w-4" />
                  }
                  title="Student Assignment"
                />

                {isAssigned ? (
                  <div className="rounded-xl border border-blue-200 bg-blue-50 p-4 dark:border-blue-900/50 dark:bg-blue-950/20">
                    <div className="flex items-start gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/40">
                        <GraduationCap className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      </div>

                      <div className="min-w-0">
                        <p className="text-xs font-medium uppercase tracking-wide text-blue-600 dark:text-blue-400">
                          Assigned Student
                        </p>

                        <p className="mt-1 break-words font-medium text-slate-900 dark:text-white">
                          {project.studentName ||
                            "Student assigned"}
                        </p>

                        {(project.studentId ||
                          project.assignedStudentId ||
                          project.assignedCandidateId) && (
                          <p className="mt-1 break-all font-mono text-xs text-slate-500 dark:text-slate-400">
                            ID:{" "}
                            {String(
                              project.studentId ||
                                project.assignedStudentId ||
                                project.assignedCandidateId
                            )}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 dark:border-amber-900/50 dark:bg-amber-950/20">
                    <div className="flex items-start gap-3">
                      <Clock3 className="mt-0.5 h-5 w-5 shrink-0 text-amber-600 dark:text-amber-400" />

                      <div>
                        <p className="font-medium text-amber-800 dark:text-amber-300">
                          Not assigned
                        </p>

                        <p className="mt-1 text-sm leading-5 text-amber-700 dark:text-amber-400">
                          This project has not been
                          assigned to a student yet.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </section>

              {/* ----------------------------------------------------------- */}
              {/* PDF                                                          */}
              {/* ----------------------------------------------------------- */}

              <section>
                <SectionHeading
                  icon={
                    <FileText className="h-4 w-4" />
                  }
                  title="Project Document"
                />

                {pdfUrl ? (
                  <div className="overflow-hidden rounded-xl border border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-800/40">
                    {/* PDF toolbar */}
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-900">
                      <span className="text-xs font-medium text-slate-600 dark:text-slate-300">
                        Project PDF
                      </span>

                      <div className="flex items-center gap-1">
                        {onPreviewPdf && (
                          <button
                            type="button"
                            onClick={() =>
                              onPreviewPdf(project)
                            }
                            className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-slate-600 transition hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            Full Preview
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={handleOpenPdf}
                          className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-slate-600 transition hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                          Open
                        </button>

                        <button
                          type="button"
                          onClick={handleDownloadPdf}
                          className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-slate-600 transition hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                        >
                          <Download className="h-3.5 w-3.5" />
                          Download
                        </button>
                      </div>
                    </div>

                    {/* PDF */}
                    <div className="relative h-[420px] bg-slate-100 dark:bg-slate-950">
                      {pdfLoading && (
                        <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-100 dark:bg-slate-950">
                          <div className="text-center">
                            <div className="mx-auto mb-3 h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-indigo-600 dark:border-slate-700 dark:border-t-indigo-400" />

                            <p className="text-sm text-slate-500 dark:text-slate-400">
                              Loading PDF...
                            </p>
                          </div>
                        </div>
                      )}

                      {pdfError ? (
                        <div className="flex h-full items-center justify-center p-6">
                          <div className="max-w-sm text-center">
                            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/30">
                              <AlertCircle className="h-6 w-6 text-red-600 dark:text-red-400" />
                            </div>

                            <h4 className="mt-4 font-medium text-slate-900 dark:text-white">
                              PDF preview unavailable
                            </h4>

                            <p className="mt-2 text-sm leading-5 text-slate-500 dark:text-slate-400">
                              The PDF could not be displayed
                              inside this window. You can
                              open it in a new browser tab.
                            </p>

                            <button
                              type="button"
                              onClick={handleOpenPdf}
                              className="mt-4 inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-indigo-700"
                            >
                              <ExternalLink className="h-4 w-4" />
                              Open PDF
                            </button>
                          </div>
                        </div>
                      ) : (
                        <iframe
                          key={pdfUrl}
                          src={pdfUrl}
                          title={`PDF for ${
                            project.title ||
                            "project"
                          }`}
                          className="h-full w-full border-0"
                          onLoad={() =>
                            setPdfLoading(false)
                          }
                          onError={() => {
                            setPdfLoading(false);
                            setPdfError(true);
                          }}
                        />
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-6 text-center dark:border-slate-700 dark:bg-slate-800/40">
                    <FileText className="mx-auto h-8 w-8 text-slate-400" />

                    <p className="mt-3 text-sm font-medium text-slate-700 dark:text-slate-300">
                      No project PDF available
                    </p>

                    <p className="mt-1 text-xs text-slate-400 dark:text-slate-500">
                      A project document has not been
                      generated or uploaded.
                    </p>
                  </div>
                )}
              </section>

              {/* ----------------------------------------------------------- */}
              {/* Metadata                                                     */}
              {/* ----------------------------------------------------------- */}

              <section>
                <SectionHeading
                  icon={
                    <CalendarDays className="h-4 w-4" />
                  }
                  title="Project Information"
                />

                <div className="overflow-hidden rounded-xl border border-slate-200 dark:border-slate-700">
                  <MetadataRow
                    label="Project ID"
                    value={
                      projectId || "Not available"
                    }
                    mono
                  />

                  <MetadataRow
                    label="Created"
                    value={formatDateTime(
                      project.createdAt
                    )}
                  />

                  <MetadataRow
                    label="Last Updated"
                    value={formatDateTime(
                      project.updatedAt
                    )}
                    last
                  />
                </div>
              </section>
            </div>
          </div>
        </div>

        {/* ================================================================== */}
        {/* Footer                                                            */}
        {/* ================================================================== */}

        <div className="flex shrink-0 flex-col-reverse gap-3 border-t border-slate-200 bg-white px-6 py-4 dark:border-slate-700 dark:bg-slate-900 sm:flex-row sm:items-center sm:justify-between">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center justify-center rounded-lg border border-slate-300 px-5 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50 dark:border-slate-600 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            Close
          </button>

          <div className="flex flex-col gap-2 sm:flex-row">
            {onEdit && (
              <button
                type="button"
                onClick={() => onEdit(project)}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 px-5 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50 dark:border-slate-600 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <Pencil className="h-4 w-4" />
                Edit Project
              </button>
            )}

            {onAssign && !isAssigned && (
              <button
                type="button"
                onClick={() => onAssign(project)}
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
              >
                <UserPlus className="h-4 w-4" />
                Assign Student
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* UI Components                                                              */
/* -------------------------------------------------------------------------- */

function SectionHeading({
  icon,
  title,
}: {
  icon: React.ReactNode;
  title: string;
}) {
  return (
    <div className="mb-3 flex items-center gap-2">
      <div className="flex h-7 w-7 items-center justify-center rounded-md bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
        {icon}
      </div>

      <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
        {title}
      </h3>
    </div>
  );
}

function InfoCard({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-400 dark:text-slate-500">
        {label}
      </p>

      <p className="mt-1 break-words text-sm font-medium text-slate-900 dark:text-white">
        {value}
      </p>
    </div>
  );
}

function MetadataRow({
  label,
  value,
  mono = false,
  last = false,
}: {
  label: string;
  value: string;
  mono?: boolean;
  last?: boolean;
}) {
  return (
    <div
      className={`flex items-start justify-between gap-4 px-4 py-3 ${
        !last
          ? "border-b border-slate-200 dark:border-slate-700"
          : ""
      }`}
    >
      <span className="shrink-0 text-xs font-medium text-slate-500 dark:text-slate-400">
        {label}
      </span>

      <span
        className={`max-w-[65%] break-all text-right text-xs text-slate-700 dark:text-slate-300 ${
          mono ? "font-mono" : ""
        }`}
      >
        {value}
      </span>
    </div>
  );
}

function EmptyText({
  text,
}: {
  text: string;
}) {
  return (
    <p className="text-sm text-slate-400 dark:text-slate-500">
      {text}
    </p>
  );
}