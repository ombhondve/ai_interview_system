"use client";

import React, { ChangeEvent, FormEvent, useEffect, useState } from "react";

/* =========================================================
   TYPES
========================================================= */

export interface ProjectFormData {
  title: string;
  role: string;
  difficulty: string;
  description: string;
  technologies: string[];
  briefUrl?: string;
  briefFile?: File | null;
  status?: string;
}

export interface ProjectFormProps {
  initialData?: Partial<ProjectFormData>;
  onSubmit: (data: ProjectFormData) => void | Promise<void>;
  onCancel?: () => void;
  loading?: boolean;
  submitLabel?: string;
}

/* =========================================================
   DEFAULT VALUES
========================================================= */

const DEFAULT_FORM_DATA: ProjectFormData = {
  title: "",
  role: "",
  difficulty: "",
  description: "",
  technologies: [],
  briefUrl: "",
  briefFile: null,
  status: "draft",
};

/* =========================================================
   COMPONENT
========================================================= */

export default function ProjectForm({
  initialData,
  onSubmit,
  onCancel,
  loading = false,
  submitLabel = "Create Project",
}: ProjectFormProps) {
  const [formData, setFormData] =
    useState<ProjectFormData>({
      ...DEFAULT_FORM_DATA,
      ...initialData,
      technologies: initialData?.technologies ?? [],
      briefFile: initialData?.briefFile ?? null,
    });

  const [technologyInput, setTechnologyInput] =
    useState("");

  const [errors, setErrors] =
    useState<Record<string, string>>({});

  /* =======================================================
     UPDATE FORM WHEN INITIAL DATA CHANGES
  ======================================================= */

  useEffect(() => {
    setFormData({
      ...DEFAULT_FORM_DATA,
      ...initialData,
      technologies: initialData?.technologies ?? [],
      briefFile: initialData?.briefFile ?? null,
    });
  }, [initialData]);

  /* =======================================================
     FIELD CHANGE
  ======================================================= */

  const handleChange = (
    event: ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = event.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));

    setErrors((previous) => {
      if (!previous[name]) {
        return previous;
      }

      const next = { ...previous };
      delete next[name];

      return next;
    });
  };

  /* =======================================================
     FILE CHANGE
  ======================================================= */

  const handleFileChange = (
    event: ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0] ?? null;

    if (!file) {
      setFormData((previous) => ({
        ...previous,
        briefFile: null,
      }));

      return;
    }

    /* -----------------------------------------------
       Validate file type
    ------------------------------------------------ */

    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "text/plain",
    ];

    if (!allowedTypes.includes(file.type)) {
      setErrors((previous) => ({
        ...previous,
        briefFile:
          "Please upload a PDF, DOC, DOCX, or TXT file.",
      }));

      event.target.value = "";

      setFormData((previous) => ({
        ...previous,
        briefFile: null,
      }));

      return;
    }

    /* -----------------------------------------------
       Validate file size
       Maximum: 10 MB
    ------------------------------------------------ */

    const MAX_FILE_SIZE = 10 * 1024 * 1024;

    if (file.size > MAX_FILE_SIZE) {
      setErrors((previous) => ({
        ...previous,
        briefFile: "File size must be less than 10 MB.",
      }));

      event.target.value = "";

      setFormData((previous) => ({
        ...previous,
        briefFile: null,
      }));

      return;
    }

    setErrors((previous) => {
      const next = { ...previous };
      delete next.briefFile;
      return next;
    });

    setFormData((previous) => ({
      ...previous,
      briefFile: file,
    }));
  };

  /* =======================================================
     TECHNOLOGY
  ======================================================= */

  const addTechnology = () => {
    const technology = technologyInput.trim();

    if (!technology) {
      return;
    }

    const alreadyExists = formData.technologies.some(
      (item) =>
        item.toLowerCase() === technology.toLowerCase()
    );

    if (alreadyExists) {
      setTechnologyInput("");
      return;
    }

    setFormData((previous) => ({
      ...previous,
      technologies: [
        ...previous.technologies,
        technology,
      ],
    }));

    setTechnologyInput("");
  };

  const removeTechnology = (technology: string) => {
    setFormData((previous) => ({
      ...previous,
      technologies: previous.technologies.filter(
        (item) => item !== technology
      ),
    }));
  };

  const handleTechnologyKeyDown = (
    event: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (event.key === "Enter") {
      event.preventDefault();
      addTechnology();
    }
  };

  /* =======================================================
     VALIDATION
  ======================================================= */

  const validate = () => {
    const nextErrors: Record<string, string> = {};

    if (!formData.title.trim()) {
      nextErrors.title = "Project title is required.";
    }

    if (!formData.role.trim()) {
      nextErrors.role = "Project role is required.";
    }

    if (!formData.difficulty.trim()) {
      nextErrors.difficulty =
        "Please select a difficulty level.";
    }

    if (!formData.description.trim()) {
      nextErrors.description =
        "Project description is required.";
    }

    if (formData.technologies.length === 0) {
      nextErrors.technologies =
        "Add at least one technology.";
    }

    if (
      !formData.briefUrl?.trim() &&
      !formData.briefFile
    ) {
      /*
       * Do not make the brief mandatory unless your backend
       * requires it.
       *
       * If it should be mandatory, uncomment:
       *
       * nextErrors.brief =
       *   "Please provide a brief URL or upload a file.";
       */
    }

    setErrors(nextErrors);

    return Object.keys(nextErrors).length === 0;
  };

  /* =======================================================
     SUBMIT
  ======================================================= */

  const handleSubmit = async (
    event: FormEvent<HTMLFormElement>
  ) => {
    event.preventDefault();

    if (loading) {
      return;
    }

    if (!validate()) {
      return;
    }

    await onSubmit({
      ...formData,
      title: formData.title.trim(),
      role: formData.role.trim(),
      description: formData.description.trim(),
      briefUrl: formData.briefUrl?.trim() || "",
      briefFile: formData.briefFile ?? null,
      technologies: formData.technologies.map(
        (technology) => technology.trim()
      ),
    });
  };

  /* =======================================================
     RENDER
  ======================================================= */

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-6"
      noValidate
    >
      {/* ===================================================
          TITLE
      =================================================== */}

      <div>
        <label
          htmlFor="title"
          className="mb-2 block text-sm font-medium"
        >
          Project Title
        </label>

        <input
          id="title"
          name="title"
          type="text"
          value={formData.title}
          onChange={handleChange}
          placeholder="Enter project title"
          disabled={loading}
          className="w-full rounded-lg border px-3 py-2"
        />

        {errors.title && (
          <p className="mt-1 text-sm text-red-600">
            {errors.title}
          </p>
        )}
      </div>

      {/* ===================================================
          ROLE
      =================================================== */}

      <div>
        <label
          htmlFor="role"
          className="mb-2 block text-sm font-medium"
        >
          Role
        </label>

        <input
          id="role"
          name="role"
          type="text"
          value={formData.role}
          onChange={handleChange}
          placeholder="e.g. Full Stack Developer"
          disabled={loading}
          className="w-full rounded-lg border px-3 py-2"
        />

        {errors.role && (
          <p className="mt-1 text-sm text-red-600">
            {errors.role}
          </p>
        )}
      </div>

      {/* ===================================================
          DIFFICULTY
      =================================================== */}

      <div>
        <label
          htmlFor="difficulty"
          className="mb-2 block text-sm font-medium"
        >
          Difficulty
        </label>

        <select
          id="difficulty"
          name="difficulty"
          value={formData.difficulty}
          onChange={handleChange}
          disabled={loading}
          className="w-full rounded-lg border px-3 py-2"
        >
          <option value="">
            Select difficulty
          </option>

          <option value="Beginner">
            Beginner
          </option>

          <option value="Intermediate">
            Intermediate
          </option>

          <option value="Advanced">
            Advanced
          </option>
        </select>

        {errors.difficulty && (
          <p className="mt-1 text-sm text-red-600">
            {errors.difficulty}
          </p>
        )}
      </div>

      {/* ===================================================
          DESCRIPTION
      =================================================== */}

      <div>
        <label
          htmlFor="description"
          className="mb-2 block text-sm font-medium"
        >
          Description
        </label>

        <textarea
          id="description"
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Describe the project..."
          rows={5}
          disabled={loading}
          className="w-full resize-y rounded-lg border px-3 py-2"
        />

        {errors.description && (
          <p className="mt-1 text-sm text-red-600">
            {errors.description}
          </p>
        )}
      </div>

      {/* ===================================================
          TECHNOLOGIES
      =================================================== */}

      <div>
        <label
          htmlFor="technology"
          className="mb-2 block text-sm font-medium"
        >
          Technologies
        </label>

        <div className="flex gap-2">
          <input
            id="technology"
            type="text"
            value={technologyInput}
            onChange={(event) =>
              setTechnologyInput(event.target.value)
            }
            onKeyDown={handleTechnologyKeyDown}
            placeholder="e.g. React"
            disabled={loading}
            className="flex-1 rounded-lg border px-3 py-2"
          />

          <button
            type="button"
            onClick={addTechnology}
            disabled={
              loading || !technologyInput.trim()
            }
            className="rounded-lg border px-4 py-2"
          >
            Add
          </button>
        </div>

        {formData.technologies.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {formData.technologies.map(
              (technology) => (
                <span
                  key={technology}
                  className="inline-flex items-center gap-2 rounded-full border px-3 py-1 text-sm"
                >
                  {technology}

                  <button
                    type="button"
                    onClick={() =>
                      removeTechnology(technology)
                    }
                    disabled={loading}
                    aria-label={`Remove ${technology}`}
                    className="font-bold"
                  >
                    ×
                  </button>
                </span>
              )
            )}
          </div>
        )}

        {errors.technologies && (
          <p className="mt-1 text-sm text-red-600">
            {errors.technologies}
          </p>
        )}
      </div>

      {/* ===================================================
          BRIEF URL
      =================================================== */}

      <div>
        <label
          htmlFor="briefUrl"
          className="mb-2 block text-sm font-medium"
        >
          Brief URL
        </label>

        <input
          id="briefUrl"
          name="briefUrl"
          type="url"
          value={formData.briefUrl ?? ""}
          onChange={handleChange}
          placeholder="https://example.com/project-brief"
          disabled={loading}
          className="w-full rounded-lg border px-3 py-2"
        />
      </div>

      {/* ===================================================
          BRIEF FILE
      =================================================== */}

      <div>
        <label
          htmlFor="briefFile"
          className="mb-2 block text-sm font-medium"
        >
          Project Brief File
        </label>

        <input
          id="briefFile"
          name="briefFile"
          type="file"
          accept=".pdf,.doc,.docx,.txt,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain"
          onChange={handleFileChange}
          disabled={loading}
          className="w-full rounded-lg border px-3 py-2"
        />

        {formData.briefFile && (
          <div className="mt-2 rounded-lg border p-3 text-sm">
            <p className="font-medium">
              Selected file
            </p>

            <p className="mt-1">
              {formData.briefFile.name}
            </p>

            <p className="text-gray-500">
              {(
                formData.briefFile.size /
                1024 /
                1024
              ).toFixed(2)}{" "}
              MB
            </p>

            <button
              type="button"
              onClick={() =>
                setFormData((previous) => ({
                  ...previous,
                  briefFile: null,
                }))
              }
              disabled={loading}
              className="mt-2 text-sm text-red-600"
            >
              Remove file
            </button>
          </div>
        )}

        {errors.briefFile && (
          <p className="mt-1 text-sm text-red-600">
            {errors.briefFile}
          </p>
        )}
      </div>

      {/* ===================================================
          STATUS
      =================================================== */}

      <div>
        <label
          htmlFor="status"
          className="mb-2 block text-sm font-medium"
        >
          Status
        </label>

        <select
          id="status"
          name="status"
          value={formData.status ?? "draft"}
          onChange={handleChange}
          disabled={loading}
          className="w-full rounded-lg border px-3 py-2"
        >
          <option value="draft">
            Draft
          </option>

          <option value="active">
            Active
          </option>

          <option value="inactive">
            Inactive
          </option>
        </select>
      </div>

      {/* ===================================================
          ACTIONS
      =================================================== */}

      <div className="flex items-center justify-end gap-3 border-t pt-4">
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            disabled={loading}
            className="rounded-lg border px-4 py-2"
          >
            Cancel
          </button>
        )}

        <button
          type="submit"
          disabled={loading}
          className="rounded-lg bg-black px-5 py-2 text-white disabled:cursor-not-allowed disabled:opacity-50"
        >
          {loading
            ? "Saving..."
            : submitLabel}
        </button>
      </div>
    </form>
  );
}